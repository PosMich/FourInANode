FourInANode
===========

Four in a Node

REQUIREMENTS
===========
* npm install socket.io

RUN
===========
* install required packages
* run "node fourinanode.js" in your terminal
* open index.html with your browser (chrome recommended)
* enter a name (more than 5 chars)
* play :)

